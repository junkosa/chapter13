class HomesController < ApplicationController
  def top
  end

  def about
  end

  def sign_up
  end

  def log_in
  end
end