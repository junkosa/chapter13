Rails.application.routes.draw do
  devise_for :users
  root to: 'homes#top'
  get 'home/about', to: 'homes#about'
  get 'users/;:id', to: 'users#show'
  get 'users/', to: 'users#index'
  get 'books/', to: 'books#index'
  post 'books/', to: 'books#create'
  resources :users, only: [:index, :show, :edit, :update] # 追加
  resources :books, only: [:index, :show, :create, :edit, :update, :destroy]
end